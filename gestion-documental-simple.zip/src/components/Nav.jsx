import React from 'react'

export default function Nav({ page, setPage }){
  const tabs = [
    ['documentos','Documentos'],
    ['ventas','Ventas'],
    ['admin','Admin']
  ]
  return (
    <div className="row" style={{marginBottom:12}}>
      {tabs.map(([id,label]) => (
        <button key={id} className={page===id?'':'secondary'} onClick={()=>setPage(id)}>{label}</button>
      ))}
    </div>
  )
}