import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabase'

export default function Admin(){
  const [usuarios,setUsuarios] = useState([])
  const [form,setForm] = useState({ email:'', rol:'viewer', area:'Administración' })

  useEffect(()=>{ load() },[])

  async function load(){
    const { data } = await supabase.from('usuarios').select('*').order('id', { ascending:false })
    setUsuarios(data||[])
  }

  async function add(e){
    e.preventDefault()
    const { data } = await supabase.from('usuarios').insert([form]).select()
    setUsuarios([...(data||[]), ...usuarios])
    setForm({ email:'', rol:'viewer', area:'Administración' })
  }

  return (
    <div className="container">
      <div className="card">
        <form className="row" onSubmit={add}>
          <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} required />
          <select value={form.rol} onChange={e=>setForm({...form, rol:e.target.value})}>
            <option>admin</option><option>vendedor</option><option>colaborador</option><option>viewer</option>
          </select>
          <select value={form.area} onChange={e=>setForm({...form, area:e.target.value})}>
            <option>Administración</option><option>Comercial</option><option>Operaciones</option><option>RRHH</option><option>Finanzas</option>
          </select>
          <button type="submit">Crear Usuario</button>
        </form>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Email</th><th>Rol</th><th>Área</th></tr></thead>
          <tbody>
            {usuarios.map(u => (
              <tr key={u.id}><td>{u.email}</td><td>{u.rol}</td><td>{u.area}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
