import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabase'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

export default function Ventas(){
  const [ventas,setVentas] = useState([])
  const [form,setForm] = useState({ vendedor:'', producto:'', cantidad:0, total:0 })
  const [query,setQuery] = useState('')

  useEffect(()=>{ load() },[])

  async function load(){
    const { data } = await supabase.from('ventas').select('*').order('id', { ascending:false })
    setVentas(data||[])
  }

  async function addVenta(e){
    e.preventDefault()
    const { data } = await supabase.from('ventas').insert([form]).select()
    setVentas([...(data||[]), ...ventas])
    setForm({ vendedor:'', producto:'', cantidad:0, total:0 })
  }

  const filtered = ventas.filter(v => 
    v.vendedor.toLowerCase().includes(query.toLowerCase()) ||
    v.producto.toLowerCase().includes(query.toLowerCase())
  )

  const byVendedor = filtered.reduce((acc, v) => { acc[v.vendedor] = (acc[v.vendedor]||0) + Number(v.total||0); return acc }, {})
  const chartData = Object.keys(byVendedor).map(k => ({ vendedor:k, total: byVendedor[k] }))

  return (
    <div className="container">
      <div className="card">
        <form className="row" onSubmit={addVenta}>
          <input placeholder="Vendedor" value={form.vendedor} onChange={e=>setForm({...form, vendedor:e.target.value})} required />
          <input placeholder="Producto" value={form.producto} onChange={e=>setForm({...form, producto:e.target.value})} required />
          <input type="number" placeholder="Cantidad" value={form.cantidad} onChange={e=>setForm({...form, cantidad:parseInt(e.target.value||0)})} />
          <input type="number" placeholder="Total $" value={form.total} onChange={e=>setForm({...form, total:parseFloat(e.target.value||0)})} />
          <button type="submit">Guardar</button>
        </form>
      </div>

      <div className="card">
        <div className="row" style={{justifyContent:'space-between'}}>
          <input placeholder="Buscar..." value={query} onChange={e=>setQuery(e.target.value)} style={{flex:1}} />
          <span style={{alignSelf:'center'}}>Total: {filtered.length}</span>
        </div>
        <table>
          <thead><tr><th>Vendedor</th><th>Producto</th><th>Cantidad</th><th>Total $</th></tr></thead>
          <tbody>
            {filtered.map(v => (
              <tr key={v.id}>
                <td>{v.vendedor}</td>
                <td>{v.producto}</td>
                <td>{v.cantidad}</td>
                <td>{v.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Ventas por Vendedor</h3>
        <div style={{width:'100%', height:300}}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <XAxis dataKey="vendedor" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="total" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
