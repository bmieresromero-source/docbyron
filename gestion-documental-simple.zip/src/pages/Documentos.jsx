import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabase'
import jsPDF from 'jspdf'

export default function Documentos(){
  const [docs,setDocs] = useState([])
  const [form,setForm] = useState({ nombre:'', tipo:'PDF', area:'Administración' })
  const [query,setQuery] = useState('')

  useEffect(()=>{ load() },[])

  async function load(){
    const { data, error } = await supabase.from('documentos').select('*').order('id', { ascending:false })
    if(!error) setDocs(data||[])
  }

  async function addDoc(e){
    e.preventDefault()
    const { data, error } = await supabase.from('documentos').insert([form]).select()
    if(!error){ setDocs([...(data||[]), ...docs]); setForm({ nombre:'', tipo:'PDF', area:'Administración' }) }
  }

  async function remove(id){
    await supabase.from('documentos').delete().eq('id', id)
    setDocs(docs.filter(d=>d.id!==id))
  }

  function actaPDF(doc){
    const pdf = new jsPDF()
    pdf.text('ACTA DE ENTREGA', 20, 20)
    pdf.text('Documento: '+doc.nombre, 20, 35)
    pdf.text('Tipo: '+doc.tipo, 20, 45)
    pdf.text('Área: '+doc.area, 20, 55)
    pdf.text('Fecha: '+ new Date().toLocaleDateString(), 20, 70)
    pdf.save('Acta_'+doc.nombre+'.pdf')
  }

  const filtered = docs.filter(d =>
    d.nombre.toLowerCase().includes(query.toLowerCase()) ||
    d.area.toLowerCase().includes(query.toLowerCase()) ||
    d.tipo.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <div className="container">
      <div className="card">
        <form className="row" onSubmit={addDoc}>
          <input placeholder="Nombre" value={form.nombre} onChange={e=>setForm({...form, nombre:e.target.value})} required />
          <select value={form.tipo} onChange={e=>setForm({...form, tipo:e.target.value})}>
            <option>PDF</option><option>Word</option><option>Excel</option><option>Imagen</option><option>Texto</option>
          </select>
          <select value={form.area} onChange={e=>setForm({...form, area:e.target.value})}>
            <option>Administración</option><option>Comercial</option><option>Operaciones</option><option>RRHH</option><option>Finanzas</option>
          </select>
          <button type="submit">Guardar</button>
        </form>
      </div>

      <div className="card">
        <div className="row" style={{justifyContent:'space-between'}}>
          <input placeholder="Buscar..." value={query} onChange={e=>setQuery(e.target.value)} style={{flex:1}} />
          <span style={{alignSelf:'center'}}>Total: {filtered.length}</span>
        </div>
        <table>
          <thead><tr><th>Nombre</th><th>Tipo</th><th>Área</th><th>Acciones</th></tr></thead>
          <tbody>
            {filtered.map(doc => (
              <tr key={doc.id}>
                <td>{doc.nombre}</td>
                <td>{doc.tipo}</td>
                <td>{doc.area}</td>
                <td>
                  <button className="secondary" onClick={()=>actaPDF(doc)}>Acta</button>
                  <button className="secondary" onClick={()=>remove(doc.id)}>Eliminar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
