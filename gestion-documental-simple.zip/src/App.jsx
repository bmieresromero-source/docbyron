import React, { useEffect, useState } from 'react'
import Nav from './components/Nav'
import Documentos from './pages/Documentos'
import Ventas from './pages/Ventas'
import Admin from './pages/Admin'
import { supabase } from './services/supabase'

export default function App(){
  const [page,setPage] = useState('documentos')
  const [user,setUser] = useState(null)

  useEffect(()=>{
    supabase.auth.getUser().then(({ data }) => setUser(data?.user || null))
  },[])

  async function login(){ await supabase.auth.signInWithOAuth({ provider: 'google' }) }
  async function logout(){ await supabase.auth.signOut(); setUser(null) }

  return (
    <div className="container">
      <h1>Gestión Documental</h1>
      <div className="row" style={{justifyContent:'space-between'}}>
        <Nav page={page} setPage={setPage} />
        <div>
          {user ? (<button className="secondary" onClick={logout}>Salir</button>) : (<button onClick={login}>Entrar</button>)}
        </div>
      </div>
      {page==='documentos' && <Documentos/>}
      {page==='ventas' && <Ventas/>}
      {page==='admin' && <Admin/>}
    </div>
  )
}
