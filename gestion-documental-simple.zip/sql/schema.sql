-- Tablas básicas
create table if not exists usuarios (
  id bigserial primary key,
  email text unique not null,
  rol text not null check (rol in ('admin','vendedor','colaborador','viewer')),
  area text not null default 'Administración'
);

create table if not exists documentos (
  id bigserial primary key,
  nombre text not null,
  tipo text not null,
  area text not null,
  creado_en timestamp with time zone default now()
);

create table if not exists ventas (
  id bigserial primary key,
  vendedor text not null,
  producto text not null,
  cantidad int not null default 0,
  total numeric not null default 0,
  creado_en timestamp with time zone default now()
);

-- RLS básico (ejemplo). Ajusta según tus necesidades.
alter table documentos enable row level security;
alter table ventas enable row level security;
alter table usuarios enable row level security;

-- Políticas de ejemplo: lectura pública autenticada
create policy if not exists doc_select on documentos for select using (auth.role() = 'authenticated');
create policy if not exists ventas_select on ventas for select using (auth.role() = 'authenticated');
create policy if not exists usuarios_select on usuarios for select using (auth.role() = 'authenticated');

-- Inserción permitida a cualquier autenticado
create policy if not exists doc_insert on documentos for insert with check (auth.role() = 'authenticated');
create policy if not exists ventas_insert on ventas for insert with check (auth.role() = 'authenticated');
create policy if not exists usuarios_insert on usuarios for insert with check (auth.role() = 'authenticated');
